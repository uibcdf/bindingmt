"""Finite original-packet default IO receiving; no molecular preparation/execution."""
import ast,functools,hashlib,importlib.abc,importlib.util,json,os,socket,subprocess,sys
from pathlib import Path
root=Path(os.environ['BINDINGMT_GATE_ROOT']);task=root/'.molsyssuite/h5msm-default-client-20261115';attempt=Path.cwd();packet=task/'packet'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,value):Path(p).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def snapshot():
 result={}
 for name in ['bindingmt','molsysmt','pyunitwizard','argdigest','smonitor','depdigest']:
  base=root if name=='bindingmt' else root.parent/name
  result[name]={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip(),'runtime':{str(p.relative_to(base)):sha(p) for p in sorted((base/name).rglob('*.py'))}}
 result['inputs']={str(p.relative_to(task)):sha(p) for p in [task/'oracle.py',task/'worker.py',*sorted(packet.iterdir())] if p.is_file()}
 return result
before=snapshot();save(attempt/'sources-before.json',before)
manifest=json.loads((packet/'manifest.json').read_text())
for case in manifest['fixtures']:
 for name,item in case['files'].items():assert sha(packet/name)==item['sha256']
blocked={'vina','rdkit','openmm','pdbfixer','topomt','pharmacophoremt','molsysviewer'};forbidden_calls=[]
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in blocked:raise AssertionError('Original/optional engine import: '+fullname)
sys.meta_path.insert(0,Block())
import h5py,numpy as np,molsysmt as msm,pyunitwizard as puw
import molsysmt._rust as native
native_path=Path(native.__file__).resolve();assert native_path==root.parent/'molsysmt/molsysmt/_rust.abi3.so'
assert sha(native_path)=='2dbcf13d148cb3ae13a5908707fcdd61c75a2de5027e50c566ce07de81bdb038'
assert any(str(native_path) in line and '(deleted)' not in line for line in Path('/proc/self/maps').read_text().splitlines())
def reject(name):
 def fail(*args,**kwargs):forbidden_calls.append(name);raise AssertionError('Unrequested execution: '+name)
 return fail
for name in dir(native):
 if not name.startswith('_') and callable(getattr(native,name)):setattr(native,name,reject('molsysmt._rust.'+name))
for name in ['assign_partial_charges','assign_autodock_atom_types','add_missing_hydrogens','merge_nonpolar_hydrogens']:
 if hasattr(msm.build,name):setattr(msm.build,name,reject('molsysmt.build.'+name))
process_launcher=subprocess.Popen;socket.socket.connect=reject('network');subprocess.Popen=reject('subprocess')
spec=importlib.util.spec_from_file_location('h5msm_existing_observation_oracle',task/'oracle.py');oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
policy=sys.argv[1];scopes=sys.argv[2:] or ['complete','projected','merged'];units=['nm','ps','K','mole','dalton','e','kJ/mol','radians'] if policy=='normal' else ['pm','fs','K','mole','dalton','coulomb','J/mol','radians']
rows=[]
with puw.context(default_form='pint',default_parser='pint',standard_units=units):
 application=puw.configure.report()
 for scope in scopes:
  origin=packet/(scope+'.h5msm');original_sha=sha(origin);expected=json.loads((packet/(scope+'-expected.json')).read_text())
  with h5py.File(origin,'r') as f:original_root=dict(f.attrs)
  assert original_root['version']=='0.6'
  system=msm.h5msm.read(origin);baseline=oracle._hdf_snapshot(system);save(attempt/(scope+'-original.json'),baseline)
  assert baseline==expected,(scope,'original differs from original oracle')
  assert 0<msm.get(system,n_atoms=True)<=6 and msm.get(system,n_structures=True)==3
  for route in ['default-write','default-convert']:
   target=attempt/(scope+'-'+route+'.h5msm');assert not target.exists()
   command='msm.h5msm.write(molsys, destination)' if route=='default-write' else 'msm.convert(origin, to_form=destination)'
   event={'scope':scope,'route':route,'command':command,'format_version':'omitted','source_sha256':original_sha,'outcome':'started'};rows.append(event);save(attempt/'operations.json',rows)
   if route=='default-write':returned=msm.h5msm.write(system,target)
   else:returned=msm.convert(origin,to_form=target)
   assert target.is_file() and target.stat().st_size>0
   with h5py.File(target,'r') as f:target_root=dict(f.attrs)
   assert target_root['version']=='1.0'
   if route=='default-convert':assert json.loads(target_root['migration_source'])==original_root
   recovered=msm.h5msm.read(target);observed=oracle._hdf_snapshot(recovered);save(attempt/(scope+'-'+route+'-snapshot.json'),observed)
   assert observed==expected,(scope,route,'reopened data differs from original oracle')
   assert oracle._hdf_snapshot(system)==baseline
   assert sha(origin)==original_sha
   event.update(outcome='PASS',target=target.name,target_sha256=sha(target),target_bytes=target.stat().st_size,root=target_root,original_root=original_root,return_value=None if returned is None else str(returned),expected_oracle_sha256=sha(packet/(scope+'-expected.json')))
   save(attempt/'operations.json',rows)
  assert puw.configure.report()==application
assert not forbidden_calls and not blocked & sys.modules.keys()
subprocess.Popen=process_launcher
assert snapshot()==before
save(attempt/'receipt.json',{'policy':policy,'standard_units':units,'operations':rows,'native':{'path':str(native_path),'sha256':sha(native_path),'mapped_path_verified':True,'kernel_calls':forbidden_calls,'builder_source_authenticity':'unassessed'},'sources':before,'scope':'Finite public default-write/default-whole-file-migration receiving of unchanged original synthetic prepared mechanics fixtures; no preparation, minimization, docking, original engines, installed/public/final-pair acceptance.'})
print('PASS:',len(rows),'default operations; original sources/oracles preserved; policy',policy,'; no Rust kernel or original-engine/process/network call.')
